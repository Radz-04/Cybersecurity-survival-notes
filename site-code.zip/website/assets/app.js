(() => {
  'use strict';
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));
  const root = document.body.dataset.root || '';
  const sidebar = $('#sidebar');
  const scrim = $('#mobile-scrim');
  const menu = $('#menu-toggle');
  const themeButton = $('#theme-toggle');
  const overlay = $('#search-overlay');
  const searchButton = $('#search-open');
  const searchInput = $('#search-input');
  const searchClose = $('#search-close');
  const results = $('#search-results');
  const escapeHTML = (value) => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let index = null;
  let highlighted = 0;
  let lastFocused = null;

  function closeMenu() {
    sidebar?.classList.remove('is-open');
    document.body.classList.remove('nav-open');
    if (scrim) scrim.hidden = true;
    menu?.setAttribute('aria-expanded', 'false');
    menu?.setAttribute('aria-label', 'Open navigation');
  }
  menu?.addEventListener('click', () => {
    const show = !sidebar?.classList.contains('is-open');
    if (show) {
      sidebar?.classList.add('is-open');
      document.body.classList.add('nav-open');
      if (scrim) scrim.hidden = false;
      menu.setAttribute('aria-expanded', 'true');
      menu.setAttribute('aria-label', 'Close navigation');
    } else closeMenu();
  });
  scrim?.addEventListener('click', closeMenu);
  $$('.sidebar a').forEach(link => link.addEventListener('click', closeMenu));
  window.addEventListener('resize', () => { if (window.innerWidth > 820) closeMenu(); });

  function setTheme(theme) {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('cs-theme', theme); } catch (e) { /* storage may be unavailable */ }
    themeButton?.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
    const meta = $('meta[name="theme-color"]');
    if (meta) meta.content = theme === 'dark' ? '#111822' : '#f9fafb';
  }
  setTheme(document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light');
  themeButton?.addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));

  const ua = navigator.userAgent || '';
  const isApple = /Mac|iPhone|iPad|iPod/.test(ua);
  const shortcut = searchButton?.querySelector('kbd');
  if (shortcut) shortcut.textContent = isApple ? '⌘ K' : 'Ctrl K';

  function hint(message) {
    results.innerHTML = `<p class="search-hint">${escapeHTML(message)}</p>`;
  }
  function rank(query) {
    const terms = query.toLowerCase().trim().split(/\s+/).filter(Boolean);
    if (!terms.length || !index) return [];
    return index.map(doc => {
      const name = doc.title.toLowerCase();
      const section = doc.section.toLowerCase();
      const desc = doc.description.toLowerCase();
      const body = doc.text.toLowerCase();
      if (!terms.every(t => name.includes(t) || section.includes(t) || desc.includes(t) || body.includes(t))) return null;
      const score = terms.reduce((n,t) => n + (name.includes(t) ? 30 : 0) + (section.includes(t) ? 9 : 0) + (desc.includes(t) ? 4 : 0) + (body.includes(t) ? 1 : 0), 0);
      return {doc, score};
    }).filter(Boolean).sort((a,b) => b.score - a.score).slice(0, 15);
  }
  function mark(indexPosition) {
    const links = $$('.search-result');
    if (!links.length) return;
    highlighted = Math.max(0, Math.min(indexPosition, links.length - 1));
    links.forEach((a,i) => {
      a.classList.toggle('is-selected', i === highlighted);
      a.setAttribute('aria-selected', String(i === highlighted));
    });
    links[highlighted].scrollIntoView({block:'nearest'});
  }
  function renderSearch() {
    const query = searchInput.value.trim();
    if (!query) { hint('Search by topic, command, or keyword.'); return; }
    if (!index) { hint('Loading notes…'); return; }
    const found = rank(query);
    if (!found.length) { hint('No matching notes. Try another keyword.'); return; }
    results.innerHTML = found.map(({doc}, i) =>
      `<a class="search-result${i === 0 ? ' is-selected' : ''}" role="option" aria-selected="${i === 0}" href="${root}${encodeURI(doc.url)}"><div class="search-result-main"><strong>${escapeHTML(doc.title)}</strong><small>${escapeHTML(doc.description)}</small></div><span class="result-section">${escapeHTML(doc.section)}</span></a>`
    ).join('');
    highlighted = 0;
    $$('.search-result').forEach((element, i) => element.addEventListener('mouseenter', () => mark(i)));
  }
  async function openSearch() {
    lastFocused = document.activeElement;
    closeMenu();
    overlay.hidden = false;
    document.body.style.overflow = 'hidden';
    searchInput.focus();
    renderSearch();
    if (index) return;
    try {
      const response = await fetch(root + 'search-index.json');
      if (!response.ok) throw new Error('Search index unavailable');
      index = await response.json();
      renderSearch();
    } catch (error) { hint('Could not load search. Please check the connection and try again.'); }
  }
  function closeSearch() {
    if (overlay.hidden) return;
    overlay.hidden = true;
    document.body.style.overflow = '';
    if (lastFocused instanceof HTMLElement) lastFocused.focus();
  }
  searchButton?.addEventListener('click', openSearch);
  searchClose?.addEventListener('click', closeSearch);
  overlay?.addEventListener('click', e => { if (e.target === overlay) closeSearch(); });
  searchInput?.addEventListener('input', renderSearch);
  document.addEventListener('keydown', e => {
    const editing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) || document.activeElement?.isContentEditable;
    if (e.key === 'Escape') { closeSearch(); closeMenu(); return; }
    if ((e.key.toLowerCase() === 'k' && (e.metaKey || e.ctrlKey)) || (e.key === '/' && !editing)) {
      e.preventDefault();
      if (!overlay.hidden) searchInput.focus(); else openSearch();
      return;
    }
    if (!overlay.hidden) {
      if (e.key === 'ArrowDown') { e.preventDefault(); mark(highlighted + 1); }
      if (e.key === 'ArrowUp') { e.preventDefault(); mark(highlighted - 1); }
      if (e.key === 'Enter' && $$('.search-result').length) { e.preventDefault(); $$('.search-result')[highlighted]?.click(); }
      if (e.key === 'Tab') {
        // Keep keyboard focus within the modal.
        const focusables = [searchInput, searchClose, ...$$('.search-result')];
        const first = focusables[0], last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    }
  });

  $$('.copy-code').forEach(button => button.addEventListener('click', async () => {
    const code = button.closest('.code-block')?.querySelector('pre code')?.textContent || '';
    try {
      await navigator.clipboard.writeText(code);
      button.textContent = 'Copied'; button.classList.add('copied');
      window.setTimeout(() => { button.textContent = 'Copy'; button.classList.remove('copied'); }, 1400);
    } catch (err) {
      // Fallback for local/offline previews with no clipboard permission.
      const area = document.createElement('textarea');
      area.value = code; area.style.position = 'fixed'; area.style.opacity = '0';
      document.body.appendChild(area); area.select();
      try { document.execCommand('copy'); button.textContent = 'Copied'; window.setTimeout(() => button.textContent = 'Copy', 1400); }
      finally { area.remove(); }
    }
  }));

  const tocLinks = $$('.toc-link');
  const headings = tocLinks.map(a => {
    try { return document.querySelector(decodeURIComponent(a.getAttribute('href'))); } catch (e) { return null; }
  }).filter(Boolean);
  if (headings.length && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      const active = entries.filter(e => e.isIntersecting).sort((a,b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
      if (active) tocLinks.forEach(a => a.classList.toggle('active', a.hash === '#' + active.target.id));
    }, {rootMargin:'-105px 0px -70% 0px'});
    headings.forEach(h => observer.observe(h));
  }
  const progress = $('#read-progress');
  if (progress && document.body.classList.contains('article-page')) {
    let ticking = false;
    const update = () => {
      const maximum = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      progress.style.width = Math.min(100, (window.scrollY / maximum) * 100) + '%';
      ticking = false;
    };
    window.addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, {passive: true});
    update();
  }
})();
