/* Small, dependency-free helpers: themes, mobile navigation, local search, copy. */
(() => {
  'use strict';
  const $ = selector => document.querySelector(selector);
  const $$ = selector => Array.from(document.querySelectorAll(selector));
  const root = document.body.dataset.root || '';
  const menuButton = $('#menu-button');
  const sidebar = $('#sidebar');
  const scrim = $('#scrim');
  const themeButton = $('#theme-button');
  const searchOverlay = $('#search-overlay');
  const searchInput = $('#search-input');
  const results = $('#search-results');
  let index = null;
  let lastFocus = null;

  function setTheme(theme) {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('notes-theme', theme); } catch (_) {}
    if (themeButton) {
      themeButton.textContent = theme === 'dark' ? 'Light mode' : 'Dark mode';
      themeButton.setAttribute('aria-label', `Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`);
    }
  }
  setTheme(document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light');
  themeButton?.addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));

  function closeMenu() {
    sidebar?.classList.remove('open');
    if (scrim) scrim.hidden = true;
    menuButton?.setAttribute('aria-expanded', 'false');
  }
  menuButton?.addEventListener('click', () => {
    const open = !sidebar.classList.contains('open');
    sidebar.classList.toggle('open', open);
    scrim.hidden = !open;
    menuButton.setAttribute('aria-expanded', String(open));
  });
  scrim?.addEventListener('click', closeMenu);
  $$('.sidebar a').forEach(a => a.addEventListener('click', closeMenu));
  window.addEventListener('resize', () => { if (innerWidth > 800) closeMenu(); });

  const escapeHTML = value => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  function search() {
    const q = searchInput.value.trim().toLowerCase();
    if (!q) { results.innerHTML = '<p>Type a topic or keyword.</p>'; return; }
    if (!index) { results.innerHTML = '<p>Loading…</p>'; return; }
    const terms = q.split(/\s+/).filter(Boolean);
    const matched = index.map(doc => {
      const title = doc.title.toLowerCase();
      const section = doc.section.toLowerCase();
      const text = (doc.description + ' ' + doc.text).toLowerCase();
      if (!terms.every(t => title.includes(t) || section.includes(t) || text.includes(t))) return null;
      const score = terms.reduce((sum,t) => sum + (title.includes(t) ? 10 : 0) + (section.includes(t) ? 4 : 0) + (text.includes(t) ? 1 : 0), 0);
      return {doc,score};
    }).filter(Boolean).sort((a,b)=>b.score-a.score).slice(0,16);
    if (!matched.length) { results.innerHTML='<p>No matching notes.</p>'; return; }
    results.innerHTML = matched.map(({doc}) => `<a class="search-item" href="${root + encodeURI(doc.url)}"><strong>${escapeHTML(doc.title)}</strong><span>${escapeHTML(doc.section)}</span></a>`).join('');
  }
  async function openSearch() {
    closeMenu();
    lastFocus = document.activeElement;
    searchOverlay.hidden = false;
    document.body.style.overflow = 'hidden';
    searchInput.focus();
    if (index) return search();
    results.innerHTML = '<p>Loading…</p>';
    try {
      const response = await fetch(root+'search-index.json');
      if (!response.ok) throw Error('Could not load search index');
      index = await response.json();
      search();
    } catch (_) { results.innerHTML = '<p>Search is unavailable right now.</p>'; }
  }
  function closeSearch() {
    if (searchOverlay.hidden) return;
    searchOverlay.hidden=true;
    document.body.style.overflow='';
    lastFocus?.focus?.();
  }
  $('#open-search')?.addEventListener('click', openSearch);
  $('#close-search')?.addEventListener('click', closeSearch);
  searchOverlay?.addEventListener('click', e => { if (e.target === searchOverlay) closeSearch(); });
  searchInput?.addEventListener('input', search);
  document.addEventListener('keydown', e => {
    const editing = ['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName);
    if (e.key === 'Escape') { closeSearch(); closeMenu(); }
    if ((e.key.toLowerCase() === 'k' && (e.ctrlKey || e.metaKey)) || (e.key === '/' && !editing)) {
      e.preventDefault();
      if (searchOverlay.hidden) openSearch(); else searchInput.focus();
    }
  });
  $$('.copy-code').forEach(button => button.addEventListener('click', async () => {
    const code = button.closest('.code-block')?.querySelector('pre code')?.textContent || '';
    try {
      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(code);
      else {
        const field=document.createElement('textarea');
        field.value=code; field.style.position='fixed'; field.style.opacity='0';
        document.body.appendChild(field); field.select();
        document.execCommand('copy'); field.remove();
      }
      button.textContent='Copied';
      setTimeout(()=>button.textContent='Copy',1100);
    } catch (_) { button.textContent='Select code'; setTimeout(()=>button.textContent='Copy',1400); }
  }));
})();
