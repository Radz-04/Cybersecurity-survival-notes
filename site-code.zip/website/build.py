#!/usr/bin/env python3
"""Build Cybersecurity Survival Notes from repository Markdown for GitHub Pages.

Designed for the existing Actions workflow:
    unzip -o .github/site-code.zip -d .
    pip install -r website/requirements.txt
    python website/build.py

No copied notes in the ZIP. Reads current repository Markdown on every run.
"""
from __future__ import annotations

import html
import io
import json
import posixpath
import re
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import quote, unquote, urlsplit, urlunsplit

import mistune
from pygments import highlight
from pygments.formatters import HtmlFormatter
from pygments.lexers import TextLexer, get_lexer_by_name
from pygments.util import ClassNotFound

ROOT = Path(__file__).resolve().parent.parent
SITE = ROOT / 'website'
OUT = ROOT / '_site'
REPO_URL = 'https://github.com/Radz-04/Cybersecurity-survival-notes'
SITE_URL = 'https://radz-04.github.io/Cybersecurity-survival-notes/'
SITE_NAME = 'Cybersecurity Survival Notes'

SECTIONS = [
    ('Linux', 'Linux'),
    ('Networking', 'Networking'),
    ('Cybersecurity Fundamentals', 'Cybersecurity-fundamentals'),
    ('Tools', 'Tools'),
]
PAGE_ORDER = {
    'Linux': ['Architecture', 'Permissions', 'Cheatsheet', 'Networking'],
    'Networking': ['Basics', 'Components', 'Communication', 'Transmission', 'Protocols', 'DHCP'],
    'Cybersecurity-fundamentals': ['CIA_triad'],
    'Tools': ['Nmap'],
}
EXCLUDED_DIRS = {'website', '_site', 'node_modules', '__pycache__', '.github', '.git'}


def esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def slug(value: str) -> str:
    value = re.sub(r'<[^>]+>', '', html.unescape(value))
    value = re.sub(r'[^\w\- ]+', '', value.casefold(), flags=re.UNICODE)
    return re.sub(r'[\s_]+', '-', value).strip('-') or 'section'


def display_name(path: PurePosixPath) -> str:
    title = path.stem.replace('_', ' ').replace('-', ' ')
    return {'CIA triad': 'CIA Triad', 'DHCP': 'DHCP', 'Nmap': 'Nmap'}.get(title, title)


def html_path(path: PurePosixPath) -> str:
    return str(path.with_suffix('.html'))


def get_source():
    if (ROOT / 'Linux').is_dir() and (ROOT / 'Networking').is_dir():
        return ROOT, None
    temp = tempfile.TemporaryDirectory(prefix='cyber-notes-src-')
    url = REPO_URL + '/archive/refs/heads/main.zip'
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'cyber-notes-pages-builder/3'})
        with urllib.request.urlopen(req, timeout=45) as response:
            archive = response.read()
        with zipfile.ZipFile(io.BytesIO(archive)) as zipf:
            for member in zipf.infolist():
                destination = (Path(temp.name) / member.filename).resolve()
                if not destination.is_relative_to(Path(temp.name).resolve()):
                    raise ValueError('Unsafe archive entry')
            zipf.extractall(temp.name)
        folders = [x for x in Path(temp.name).iterdir() if x.is_dir()]
        if len(folders) != 1 or not (folders[0] / 'Networking').is_dir():
            raise ValueError('Expected Markdown folders were not found')
        return folders[0], temp
    except Exception as exc:
        temp.cleanup()
        raise SystemExit(f'Could not load the notes. Build from a repo checkout, or check GitHub connectivity: {exc}')


def get_sections(source: Path):
    discovered = []
    configured = {folder for _, folder in SECTIONS}
    candidates = SECTIONS + [
        (folder.name.replace('-', ' ').replace('_', ' ').title(), folder.name)
        for folder in sorted(source.iterdir(), key=lambda p: p.name.casefold())
        if folder.is_dir() and folder.name not in configured and folder.name not in EXCLUDED_DIRS
        and not folder.name.startswith('.') and any(folder.glob('*.md'))
    ]
    for name, folder in candidates:
        folder_path = source / folder
        if not folder_path.is_dir():
            continue
        preferred = PAGE_ORDER.get(folder, [])
        def sort_key(p):
            return (0, preferred.index(p.stem)) if p.stem in preferred else (1, p.name.casefold())
        pages = sorted([PurePosixPath(folder, p.name) for p in folder_path.glob('*.md') if p.name.lower() != 'readme.md'], key=sort_key)
        if pages:
            discovered.append({'name': name, 'folder': folder, 'pages': pages})
    return discovered


class DocumentRenderer(mistune.HTMLRenderer):
    def __init__(self):
        super().__init__(escape=True)
        self.toc = []
        self.seen = {}

    def heading(self, text, level, **attrs):
        plain = html.unescape(re.sub(r'<[^>]+>', '', text)).strip()
        base = slug(plain)
        self.seen[base] = self.seen.get(base, 0) + 1
        heading_id = base if self.seen[base] == 1 else f'{base}-{self.seen[base]}'
        if level in (2, 3):
            self.toc.append({'title': plain, 'id': heading_id, 'level': level})
        return f'<h{level} id="{esc(heading_id)}">{text}<a class="heading-anchor" href="#{esc(heading_id)}" aria-label="Link to {esc(plain)}">#</a></h{level}>\n'

    def block_code(self, code, info=None):
        language = (info or '').strip().split(maxsplit=1)[0].lower() if (info or '').strip() else ''
        try:
            lexer = get_lexer_by_name(language) if language else TextLexer()
        except ClassNotFound:
            lexer = TextLexer()
        formatted = highlight(code, lexer, HtmlFormatter(nowrap=True)).rstrip('\n')
        label = esc(language) if language else 'text'
        return (f'<div class="code-block"><div class="code-bar"><span class="code-lang">{label}</span>'
                '<button class="copy-code" type="button" aria-label="Copy code">Copy</button></div>'
                f'<pre><code>{formatted}</code></pre></div>\n')


def markup(md: str, source_path: PurePosixPath, available: set[str]):
    renderer = DocumentRenderer()
    markdown = mistune.create_markdown(renderer=renderer, plugins=['table', 'strikethrough', 'url', 'task_lists'])
    rendered = markdown(md)

    def rewrite_ref(match):
        attr, raw_url = match.group(1), html.unescape(match.group(2))
        parsed = urlsplit(raw_url)
        if parsed.scheme or parsed.netloc or raw_url.startswith(('#', '//', 'data:')):
            return match.group(0)
        if not parsed.path:
            return match.group(0)
        normalized = posixpath.normpath(posixpath.join(str(source_path.parent), unquote(parsed.path)))
        normalized = normalized.lstrip('/')
        if normalized.startswith('../'):
            return match.group(0)
        extension = PurePosixPath(normalized).suffix.lower()
        if attr == 'href' and extension == '.md':
            if normalized.lower() == 'readme.md':
                target = 'index.html'
            elif normalized in available:
                target = str(PurePosixPath(normalized).with_suffix('.html'))
            elif PurePosixPath(normalized).name.lower() == 'readme.md':
                # A few source notes link to a folder README that does not exist.
                folder = PurePosixPath(normalized).parent.name
                target = f'index.html#topic-{slug(folder)}'
            else:
                return match.group(0)
            back = '../' * len(source_path.parent.parts)
            link = back + target
            if parsed.fragment:
                link += '#' + quote(unquote(parsed.fragment), safe='-_')
            return f'{attr}="{esc(link)}"'
        if attr == 'src' and extension in {'.png', '.jpg', '.jpeg', '.webp', '.svg', '.gif'}:
            target = f'https://raw.githubusercontent.com/Radz-04/Cybersecurity-survival-notes/main/{quote(normalized)}'
            return f'src="{esc(target)}"'
        return match.group(0)

    rendered = re.sub(r'\b(href|src)="([^"]+)"', rewrite_ref, rendered)
    return rendered, renderer.toc


def summary_from_markdown(md: str, title: str) -> str:
    md = re.sub(r'```.*?```', '', md, flags=re.DOTALL)
    md = re.sub(r'!\[[^]]*\]\([^)]*\)', '', md)
    for paragraph in re.split(r'\n\s*\n', md):
        para = paragraph.strip()
        if not para or para.startswith(('#', '>', '-', '*', '|', '<', '[', '```')):
            continue
        text = re.sub(r'\[([^]]+)\]\([^)]*\)', r'\1', para)
        text = re.sub(r'[`*_~]', '', text)
        text = re.sub(r'\s+', ' ', text)
        if len(text) >= 40:
            return text[:175].rstrip(' .') + ('.' if len(text) < 175 else '…')
    return f'{title} — technical notes in Cybersecurity Survival Notes.'


def page_heading(md: str, default: str):
    match = re.search(r'^#\s+(.+?)\s*$', md, flags=re.MULTILINE)
    return re.sub(r'[`*_]', '', match.group(1)).strip() if match else default


def strip_primary_heading(md: str):
    # Prevent two h1 elements: the article template owns the page title.
    return re.sub(r'^\s*#\s+[^\n]+\n', '', md, count=1) if re.match(r'^\s*#\s+', md) else md


def nav_html(sections, current: str, root: str) -> str:
    groups = []
    for sec in sections:
        items = '\n'.join(
            f'<a class="side-link {"is-active" if str(p)==current else ""}" '
            f'href="{esc(root + html_path(p))}" {"aria-current=\"page\"" if str(p)==current else ""}>'
            f'{esc(display_name(p))}</a>' for p in sec['pages']
        )
        is_current = any(str(p) == current for p in sec['pages'])
        groups.append(
            f'<details class="side-group" {"open" if is_current or not current else ""}>'
            f'<summary><span class="side-group-label">{esc(sec["name"])}</span>'
            f'<span class="side-count">{len(sec["pages"])}</span>'
            '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>'
            f'</summary><div class="side-links">{items}</div></details>'
        )
    return '\n'.join(groups)


def page_template(*, title: str, description: str, body: str, sections, current: str='', toc=None,
                  section: str='', home: bool=False, page_url: str='', prev=None, following=None):
    root = '../' * len(PurePosixPath(current).parent.parts) if current else ''
    # PurePosixPath('a/b.md').parent.parts == ('a',) -> '../'.
    current_path = html_path(PurePosixPath(current)) if current else 'index.html'
    canonical = SITE_URL if home else SITE_URL + current_path
    source = REPO_URL + ('/blob/main/' + quote(current, safe='/') if current else '')
    page_title = SITE_NAME if home else f'{title} | {SITE_NAME}'
    toc_items = ''.join(
        f'<a href="#{esc(item["id"])}" class="toc-link toc-l{item["level"]}">{esc(item["title"])}</a>'
        for item in (toc or [])
    )
    crumbs = '' if home else (
        f'<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="{root}index.html">Home</a>'
        f'<span aria-hidden="true">/</span><span>{esc(section)}</span></nav>'
    )
    pagination = ''
    if not home and (prev or following):
        def pager(doc, label):
            if not doc: return '<div class="page-step-placeholder"></div>'
            target = root + doc['url']
            return (f'<a class="page-step" href="{esc(target)}"><span>{esc(label)}</span>'
                    f'<strong>{esc(doc["title"])}</strong></a>')
        pagination = f'<nav class="pagination" aria-label="Continue reading">{pager(prev,"Previous")}{pager(following,"Next")}</nav>'
    right = ('<aside class="outline" aria-label="On this page"><div class="outline-label">On this page</div>'
             f'<nav>{toc_items}</nav></aside>') if toc_items else '<aside class="outline empty-outline" aria-hidden="true"></aside>'
    github_link = f'{REPO_URL}/blob/main/{quote(current, safe="/")}' if current else REPO_URL
    meta_article = ('<meta property="og:type" content="website">' if home else '<meta property="og:type" content="article">')
    return f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta name="theme-color" content="#f9fafb">
<title>{esc(page_title)}</title>
<meta name="description" content="{esc(description)}">
<link rel="canonical" href="{esc(canonical)}">
<meta property="og:site_name" content="{esc(SITE_NAME)}">
<meta property="og:title" content="{esc(page_title)}">
<meta property="og:description" content="{esc(description)}">
<meta property="og:url" content="{esc(canonical)}">
{meta_article}
<meta name="twitter:card" content="summary">
<link rel="icon" href="{root}assets/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="{root}assets/style.css">
<script>try{{document.documentElement.dataset.theme=localStorage.getItem('cs-theme')||'light'}}catch(e){{document.documentElement.dataset.theme='light'}}</script>
<script defer src="{root}assets/app.js"></script>
</head>
<body class="{"home-page" if home else "article-page"}" data-root="{root}">
<a class="skip-link" href="#main">Skip to content</a>
<div class="read-progress" id="read-progress" aria-hidden="true"></div>
<header class="header">
  <div class="header-inner">
    <button class="mobile-menu icon-button" id="menu-toggle" type="button" aria-label="Open navigation" aria-controls="sidebar" aria-expanded="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
    <a class="identity" href="{root}index.html" aria-label="Cybersecurity Survival Notes, home">
      <span class="identity-symbol" aria-hidden="true"><span>CS</span></span>
      <span class="identity-label">Cybersecurity<span>Survival Notes</span></span>
    </a>
    <span class="header-separator" aria-hidden="true"></span>
    <span class="header-caption">Technical notes</span>
    <div class="header-actions">
      <button class="search-trigger" type="button" id="search-open" aria-haspopup="dialog"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg><span>Search notes</span><kbd>⌘ K</kbd></button>
      <button class="theme-toggle icon-button" id="theme-toggle" type="button" aria-label="Switch color theme" title="Toggle light / dark mode"><svg class="theme-sun" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/></svg><svg class="theme-moon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5a8.5 8.5 0 1 0 12 12Z"/></svg></button>
      <a class="github-link" href="{REPO_URL}" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor" stroke="none"><path d="M12 .9a11.1 11.1 0 0 0-3.51 21.63c.56.1.76-.24.76-.54v-2.07c-3.08.67-3.73-1.31-3.73-1.31-.51-1.28-1.24-1.63-1.24-1.63-1.01-.69.08-.67.08-.67 1.12.08 1.71 1.15 1.71 1.15.99 1.69 2.6 1.2 3.23.92.1-.72.39-1.2.71-1.48-2.46-.28-5.05-1.23-5.05-5.49 0-1.21.43-2.2 1.14-2.97-.12-.28-.5-1.4.11-2.92 0 0 .93-.3 3.05 1.13a10.6 10.6 0 0 1 5.55 0c2.12-1.43 3.05-1.13 3.05-1.13.61 1.52.23 2.64.12 2.92.71.77 1.14 1.76 1.14 2.97 0 4.27-2.59 5.21-5.06 5.49.4.34.76 1.01.76 2.04v3.04c0 .3.2.65.77.54A11.1 11.1 0 0 0 12 .9Z"/></svg><span>GitHub</span><svg class="external-arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17 17 7M8 7h9v9"/></svg></a>
    </div>
  </div>
</header>
<div class="mobile-scrim" id="mobile-scrim" hidden></div>
<div class="shell">
  <aside class="sidebar" id="sidebar" aria-label="Browse notes">
    <div class="sidebar-inner"><div class="sidebar-overline">BROWSE</div>
      <a class="side-home {"is-active" if home else ""}" href="{root}index.html" {"aria-current=\"page\"" if home else ""}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 10 9-7 9 7v10H3V10Z"/><path d="M9 20v-7h6v7"/></svg>Home</a>
      <div class="sidebar-divider"></div>
      {nav_html(sections,current,root)}
      <div class="sidebar-bottom"><span>Built from Markdown on GitHub.</span></div>
    </div>
  </aside>
  <main class="main" id="main">
    <div class="content-wrap {"wide" if home else ""}">
      {crumbs}
      {body}
      {pagination}
      {'' if home else f'<div class="source-footer"><span>Found an issue with this note?</span><a href="{esc(github_link)}" target="_blank" rel="noopener noreferrer">View source on GitHub ↗</a></div>'}
      <footer class="site-footer"><span>Cybersecurity Survival Notes</span><span>Source available on <a href="{REPO_URL}" target="_blank" rel="noopener noreferrer">GitHub</a></span></footer>
    </div>
  </main>
  {right}
</div>
<div class="search-overlay" id="search-overlay" hidden>
  <div class="search-dialog" role="dialog" aria-modal="true" aria-label="Search notes" aria-labelledby="search-title">
    <div class="search-head"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg><h2 id="search-title" class="visually-hidden">Search notes</h2><input id="search-input" type="search" spellcheck="false" autocomplete="off" placeholder="Search Linux, Nmap, DHCP…" aria-label="Search notes"><button class="search-close" id="search-close" type="button" aria-label="Close search">Esc</button></div>
    <div class="search-results" id="search-results" role="listbox" aria-label="Search results"><p class="search-hint">Search by topic, command, or keyword.</p></div>
    <div class="search-foot"><span>↑ ↓ navigate</span><span>↵ open</span><span>esc close</span></div>
  </div>
</div>
</body>
</html>'''


def build():
    source_root, temp = get_source()
    try:
        sections = get_sections(source_root)
        if not sections:
            raise SystemExit('No Markdown notes found. The repository content is required.')
        if OUT.exists():
            shutil.rmtree(OUT)
        OUT.mkdir(parents=True)
        shutil.copytree(SITE / 'assets', OUT / 'assets')
        ordered_paths = [p for sec in sections for p in sec['pages']]
        available = {str(p) for p in ordered_paths}
        docs = []
        for sec in sections:
            for path in sec['pages']:
                md = (source_root / str(path)).read_text(encoding='utf-8')
                title = page_heading(md, display_name(path))
                description = summary_from_markdown(md, title)
                content, toc = markup(strip_primary_heading(md), path, available)
                doc = {'title': title, 'nav_title': display_name(path), 'section': sec['name'],
                       'url': html_path(path), 'path': str(path), 'description': description,
                       'body': content, 'toc': toc, 'text': re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', content))[:26000]}
                docs.append(doc)
        for idx, doc in enumerate(docs):
            source_path = PurePosixPath(doc['path'])
            dest = OUT / doc['url']
            dest.parent.mkdir(parents=True, exist_ok=True)
            body = (f'<article class="prose"><header class="article-header"><h1>{esc(doc["title"])}</h1>'
                    f'<p class="article-subtitle">{esc(doc["description"])}</p></header>'
                    f'<div class="md-body">{doc["body"]}</div></article>')
            dest.write_text(page_template(title=doc['title'], description=doc['description'], body=body,
                             sections=sections, current=doc['path'], toc=doc['toc'], section=doc['section'],
                             prev=docs[idx-1] if idx else None, following=docs[idx+1] if idx+1 < len(docs) else None), encoding='utf-8')
        groups = []
        for pos, sec in enumerate(sections, 1):
            note_links = ''.join(
                f'<li><a href="{esc(html_path(path))}">{esc(display_name(path))}<span aria-hidden="true">↗</span></a></li>'
                for path in sec['pages']
            )
            groups.append(
                f'<section class="topic" id="topic-{slug(sec["folder"])}">'
                f'<div class="topic-head"><span class="topic-number">{pos:02d}</span>'
                f'<div><h3>{esc(sec["name"])}</h3><span>{len(sec["pages"])} {"note" if len(sec["pages"]) == 1 else "notes"}</span></div>'
                f'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17 17 7M8 7h9v9"/></svg></div>'
                f'<ul class="topic-links">{note_links}</ul></section>'
            )
        first_page = html_path(sections[0]['pages'][0])
        total = len(docs)
        homepage = f'''<div class="home-hero">
  <div class="eyebrow"><span class="eyebrow-line"></span>A personal technical notebook</div>
  <h1>Cybersecurity<br><span>Survival Notes.</span></h1>
  <p>Study notes and practical references on Linux, networking and security tools. Organized to be easy to revisit, and maintained in the open on GitHub.</p>
  <div class="hero-actions"><a href="#topics" class="button-primary">Explore topics <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></a><a href="{REPO_URL}" class="button-secondary" target="_blank" rel="noopener noreferrer">View repository ↗</a></div>
  <div class="hero-meta"><div><strong>{len(sections):02d}</strong><span>Topics</span></div><div><strong>{total:02d}</strong><span>Notes</span></div><div class="hero-meta-right">Written in Markdown. Read anywhere.</div></div>
</div>
<section class="topics-section" id="topics"><div class="section-intro"><div><span class="section-kicker">THE INDEX</span><h2>Find your next topic.</h2></div><p>Choose an area or jump straight into a note.</p></div><div class="topics-grid">{''.join(groups)}</div></section>
<section class="home-bottom"><div><h2>Prefer the source files?</h2><p>The notes live in a public GitHub repository. Each page here is generated from those Markdown files.</p></div><a href="{REPO_URL}" target="_blank" rel="noopener noreferrer">Browse on GitHub <span aria-hidden="true">↗</span></a></section>'''
        (OUT / 'index.html').write_text(page_template(title=SITE_NAME, description='Notes on Linux, networking, cybersecurity fundamentals and Nmap. Technical explanations and command references, open on GitHub.', body=homepage, sections=sections, home=True), encoding='utf-8')
        index = [{'title': d['title'], 'section': d['section'], 'url': d['url'],
                  'description': d['description'], 'text': html.unescape(d['text'])} for d in docs]
        (OUT / 'search-index.json').write_text(json.dumps(index, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
        sitemap_urls = [SITE_URL] + [SITE_URL + d['url'] for d in docs]
        (OUT / 'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + ''.join(f'<url><loc>{esc(u)}</loc></url>\n' for u in sitemap_urls) + '</urlset>\n', encoding='utf-8')
        (OUT / 'robots.txt').write_text('User-agent: *\nAllow: /\nSitemap: ' + SITE_URL + 'sitemap.xml\n', encoding='utf-8')
        (OUT / '.nojekyll').write_text('', encoding='utf-8')
        print(f'Success: {len(docs)} pages, {len(sections)} topics → {OUT}')
    finally:
        if temp:
            temp.cleanup()


if __name__ == '__main__':
    build()
