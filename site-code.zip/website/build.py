#!/usr/bin/env python3
"""Build Cybersecurity Survival Notes from repository Markdown for GitHub Pages.

Designed for the existing Actions workflow:
    unzip -o site-code.zip -d .
    pip install -r website/requirements.txt
    python website/build.py

No copied notes in the ZIP. Reads current repository Markdown on every run.
"""
from __future__ import annotations

import html
import io
import json
import posixpath
import re
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import quote, unquote, urlsplit, urlunsplit

import mistune
from pygments import highlight
from pygments.formatters import HtmlFormatter
from pygments.lexers import TextLexer, get_lexer_by_name
from pygments.util import ClassNotFound

ROOT = Path(__file__).resolve().parent.parent
SITE = ROOT / 'website'
OUT = ROOT / '_site'
REPO_URL = 'https://github.com/Radz-04/Cybersecurity-survival-notes'
LINKEDIN_URL = 'https://www.linkedin.com/in/radzivon-ferrigni-dioguardi-b4095a376/'
SITE_URL = 'https://radz-04.github.io/Cybersecurity-survival-notes/'
SITE_NAME = 'Cybersecurity Survival Notes'

SECTIONS = [
    ('Linux', 'Linux'),
    ('Networking', 'Networking'),
    ('Cybersecurity Fundamentals', 'Cybersecurity-fundamentals'),
    ('Tools', 'Tools'),
]
PAGE_ORDER = {
    'Linux': ['Architecture', 'Permissions', 'Cheatsheet', 'Networking'],
    'Networking': ['Basics', 'Components', 'Communication', 'Transmission', 'Protocols', 'DHCP'],
    'Cybersecurity-fundamentals': ['CIA_triad'],
    'Tools': ['Nmap'],
}
EXCLUDED_DIRS = {'website', '_site', 'node_modules', '__pycache__', '.github', '.git'}


def esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def slug(value: str) -> str:
    value = re.sub(r'<[^>]+>', '', html.unescape(value))
    value = re.sub(r'[^\w\- ]+', '', value.casefold(), flags=re.UNICODE)
    return re.sub(r'[\s_]+', '-', value).strip('-') or 'section'


def display_name(path: PurePosixPath) -> str:
    title = path.stem.replace('_', ' ').replace('-', ' ')
    return {'CIA triad': 'CIA Triad', 'DHCP': 'DHCP', 'Nmap': 'Nmap'}.get(title, title)


def html_path(path: PurePosixPath) -> str:
    return str(path.with_suffix('.html'))


def get_source():
    if (ROOT / 'Linux').is_dir() and (ROOT / 'Networking').is_dir():
        return ROOT, None
    temp = tempfile.TemporaryDirectory(prefix='cyber-notes-src-')
    url = REPO_URL + '/archive/refs/heads/main.zip'
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'cyber-notes-pages-builder/3'})
        with urllib.request.urlopen(req, timeout=45) as response:
            archive = response.read()
        with zipfile.ZipFile(io.BytesIO(archive)) as zipf:
            for member in zipf.infolist():
                destination = (Path(temp.name) / member.filename).resolve()
                if not destination.is_relative_to(Path(temp.name).resolve()):
                    raise ValueError('Unsafe archive entry')
            zipf.extractall(temp.name)
        folders = [x for x in Path(temp.name).iterdir() if x.is_dir()]
        if len(folders) != 1 or not (folders[0] / 'Networking').is_dir():
            raise ValueError('Expected Markdown folders were not found')
        return folders[0], temp
    except Exception as exc:
        temp.cleanup()
        raise SystemExit(f'Could not load the notes. Build from a repo checkout, or check GitHub connectivity: {exc}')


def get_sections(source: Path):
    discovered = []
    configured = {folder for _, folder in SECTIONS}
    candidates = SECTIONS + [
        (folder.name.replace('-', ' ').replace('_', ' ').title(), folder.name)
        for folder in sorted(source.iterdir(), key=lambda p: p.name.casefold())
        if folder.is_dir() and folder.name not in configured and folder.name not in EXCLUDED_DIRS
        and not folder.name.startswith('.') and any(folder.glob('*.md'))
    ]
    for name, folder in candidates:
        folder_path = source / folder
        if not folder_path.is_dir():
            continue
        preferred = PAGE_ORDER.get(folder, [])
        def sort_key(p):
            return (0, preferred.index(p.stem)) if p.stem in preferred else (1, p.name.casefold())
        pages = sorted([PurePosixPath(folder, p.name) for p in folder_path.glob('*.md') if p.name.lower() != 'readme.md'], key=sort_key)
        if pages:
            discovered.append({'name': name, 'folder': folder, 'pages': pages})
    return discovered


class DocumentRenderer(mistune.HTMLRenderer):
    def __init__(self):
        super().__init__(escape=True)
        self.toc = []
        self.seen = {}

    def heading(self, text, level, **attrs):
        plain = html.unescape(re.sub(r'<[^>]+>', '', text)).strip()
        base = slug(plain)
        self.seen[base] = self.seen.get(base, 0) + 1
        heading_id = base if self.seen[base] == 1 else f'{base}-{self.seen[base]}'
        if level in (2, 3):
            self.toc.append({'title': plain, 'id': heading_id, 'level': level})
        return f'<h{level} id="{esc(heading_id)}">{text}<a class="heading-anchor" href="#{esc(heading_id)}" aria-label="Link to {esc(plain)}">#</a></h{level}>\n'

    def block_code(self, code, info=None):
        language = (info or '').strip().split(maxsplit=1)[0].lower() if (info or '').strip() else ''
        try:
            lexer = get_lexer_by_name(language) if language else TextLexer()
        except ClassNotFound:
            lexer = TextLexer()
        formatted = highlight(code, lexer, HtmlFormatter(nowrap=True)).rstrip('\n')
        label = esc(language) if language else 'text'
        return (f'<div class="code-block"><div class="code-bar"><span class="code-lang">{label}</span>'
                '<button class="copy-code" type="button" aria-label="Copy code">Copy</button></div>'
                f'<pre><code>{formatted}</code></pre></div>\n')


def markup(md: str, source_path: PurePosixPath, available: set[str]):
    renderer = DocumentRenderer()
    markdown = mistune.create_markdown(renderer=renderer, plugins=['table', 'strikethrough', 'url', 'task_lists'])
    rendered = markdown(md)

    def rewrite_ref(match):
        attr, raw_url = match.group(1), html.unescape(match.group(2))
        parsed = urlsplit(raw_url)
        if parsed.scheme or parsed.netloc or raw_url.startswith(('#', '//', 'data:')):
            return match.group(0)
        if not parsed.path:
            return match.group(0)
        normalized = posixpath.normpath(posixpath.join(str(source_path.parent), unquote(parsed.path)))
        normalized = normalized.lstrip('/')
        if normalized.startswith('../'):
            return match.group(0)
        extension = PurePosixPath(normalized).suffix.lower()
        if attr == 'href' and extension == '.md':
            if normalized.lower() == 'readme.md':
                target = 'index.html'
            elif normalized in available:
                target = str(PurePosixPath(normalized).with_suffix('.html'))
            elif PurePosixPath(normalized).name.lower() == 'readme.md':
                # A few source notes link to a folder README that does not exist.
                folder = PurePosixPath(normalized).parent.name
                target = f'index.html#topic-{slug(folder)}'
            else:
                return match.group(0)
            back = '../' * len(source_path.parent.parts)
            link = back + target
            if parsed.fragment:
                link += '#' + quote(unquote(parsed.fragment), safe='-_')
            return f'{attr}="{esc(link)}"'
        if attr == 'src' and extension in {'.png', '.jpg', '.jpeg', '.webp', '.svg', '.gif'}:
            target = f'https://raw.githubusercontent.com/Radz-04/Cybersecurity-survival-notes/main/{quote(normalized)}'
            return f'src="{esc(target)}"'
        return match.group(0)

    rendered = re.sub(r'\b(href|src)="([^"]+)"', rewrite_ref, rendered)
    return rendered, renderer.toc


def summary_from_markdown(md: str, title: str) -> str:
    md = re.sub(r'```.*?```', '', md, flags=re.DOTALL)
    md = re.sub(r'!\[[^]]*\]\([^)]*\)', '', md)
    for paragraph in re.split(r'\n\s*\n', md):
        para = paragraph.strip()
        if not para or para.startswith(('#', '>', '-', '*', '|', '<', '[', '```')):
            continue
        text = re.sub(r'\[([^]]+)\]\([^)]*\)', r'\1', para)
        text = re.sub(r'[`*_~]', '', text)
        text = re.sub(r'\s+', ' ', text)
        if len(text) >= 40:
            return text[:175].rstrip(' .') + ('.' if len(text) < 175 else '…')
    return f'{title} — technical notes in Cybersecurity Survival Notes.'


def page_heading(md: str, default: str):
    match = re.search(r'^#\s+(.+?)\s*$', md, flags=re.MULTILINE)
    return re.sub(r'[`*_]', '', match.group(1)).strip() if match else default


def strip_primary_heading(md: str):
    # Prevent two h1 elements: the article template owns the page title.
    return re.sub(r'^\s*#\s+[^\n]+\n', '', md, count=1) if re.match(r'^\s*#\s+', md) else md


def nav_html(sections, current: str, root: str) -> str:
    groups = []
    for sec in sections:
        is_current = any(str(p) == current for p in sec['pages'])
        items = ''.join(
            f'<a href="{esc(root + html_path(p))}" class="nav-item{" active" if str(p)==current else ""}"'
            f'{" aria-current=\"page\"" if str(p)==current else ""}>{esc(display_name(p))}</a>'
            for p in sec['pages']
        )
        groups.append(f'<details class="nav-group" {"open" if is_current or not current else ""}>'
                      f'<summary>{esc(sec["name"])}</summary><div class="nav-list">{items}</div></details>')
    return '\n'.join(groups)


def page_template(*, title: str, description: str, body: str, sections, current: str='', toc=None,
                  section: str='', home: bool=False, prev=None, following=None):
    root = '../' * len(PurePosixPath(current).parent.parts) if current else ''
    current_path = html_path(PurePosixPath(current)) if current else 'index.html'
    canonical = SITE_URL if home else SITE_URL + current_path
    page_title = SITE_NAME if home else f'{title} | {SITE_NAME}'
    source = f'{REPO_URL}/blob/main/{quote(current, safe="/")}' if current else REPO_URL
    toclinks = ''.join(f'<a href="#{esc(item["id"])}" class="toc-item toc-l{item["level"]}">{esc(item["title"])}</a>'
                       for item in (toc or []) if item['level']==2)
    outline = f'<aside class="toc" aria-label="On this page"><span class="toc-label">On this page</span>{toclinks}</aside>' if toclinks else ''
    crumbs = '' if home else (f'<nav class="breadcrumbs" aria-label="Breadcrumbs"><a href="{root}index.html">Home</a>'
                             f'<span>/</span>{esc(section)}</nav>')
    pager = ''
    if not home and (prev or following):
        links=[]
        if prev:
            links.append(f'<a href="{esc(root + prev["url"])}" class="pager-link"><span>Previous</span><strong>{esc(prev["title"])}</strong></a>')
        if following:
            links.append(f'<a href="{esc(root + following["url"])}" class="pager-link"><span>Next</span><strong>{esc(following["title"])}</strong></a>')
        pager = f'<nav class="pager" aria-label="Other notes">{"".join(links)}</nav>'
    return f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light dark">
<title>{esc(page_title)}</title>
<meta name="description" content="{esc(description)}">
<link rel="canonical" href="{esc(canonical)}">
<meta property="og:type" content="{'website' if home else 'article'}">
<meta property="og:title" content="{esc(page_title)}">
<meta property="og:description" content="{esc(description)}">
<meta property="og:url" content="{esc(canonical)}">
<meta name="twitter:card" content="summary">
<link rel="stylesheet" href="{root}assets/style.css?v=5">
<script>try{{document.documentElement.dataset.theme=localStorage.getItem('notes-theme')||'dark'}}catch(e){{document.documentElement.dataset.theme='light'}}</script>
<script src="{root}assets/app.js?v=5" defer></script>
</head>
<body data-root="{root}">
<a href="#content" class="skip-link">Skip to content</a>
<header class="topbar"><div class="topbar-inner">
<button id="menu-button" class="nav-button" type="button" aria-controls="sidebar" aria-expanded="false">Menu</button>
<a class="brand" href="{root}index.html">Cybersecurity Survival Notes</a>
<div class="top-actions">
<button id="open-search" class="quiet-button" type="button" aria-haspopup="dialog">Search <span class="key-hint">/</span></button>
<button id="theme-button" class="quiet-button" type="button" aria-label="Switch to dark mode">Dark mode</button>
<a href="{REPO_URL}" class="github-nav" target="_blank" rel="noopener noreferrer">GitHub ↗</a>
<a href="{LINKEDIN_URL}" class="github-nav social-nav" target="_blank" rel="noopener noreferrer">LinkedIn ↗</a>
</div></div></header>
<div class="scrim" id="scrim" hidden></div>
<div class="layout">
<aside class="sidebar" id="sidebar" aria-label="Topics"><div class="sidebar-inner">
<a href="{root}index.html" class="nav-home{' active' if home else ''}" {'aria-current="page"' if home else ''}>Home</a>
{nav_html(sections,current,root)}
</div></aside>
<main id="content" class="main"><div class="content">
{crumbs}
{body}
{pager}
{'' if home else f'<p class="source-link"><a href="{esc(source)}" target="_blank" rel="noopener noreferrer">View Markdown on GitHub ↗</a></p>'}
<footer class="footer"><nav aria-label="External links"><a href="{REPO_URL}" target="_blank" rel="noopener noreferrer">GitHub</a><a href="{LINKEDIN_URL}" target="_blank" rel="noopener noreferrer">LinkedIn</a></nav></footer>
</div></main>
{outline}
</div>
<div id="search-overlay" class="search-overlay" hidden><div class="search-panel" role="dialog" aria-modal="true" aria-labelledby="search-title">
<div class="search-top"><label id="search-title" class="sr-only" for="search-input">Search notes</label>
<input id="search-input" type="search" placeholder="Search notes…" autocomplete="off" spellcheck="false">
<button id="close-search" type="button">Close</button></div>
<div id="search-results" class="search-results" aria-live="polite"><p>Type a topic or keyword.</p></div>
</div></div>
</body>
</html>'''


def build():
    source_root, temp = get_source()
    try:
        sections = get_sections(source_root)
        if not sections:
            raise SystemExit('No Markdown notes found. The repository content is required.')
        if OUT.exists():
            shutil.rmtree(OUT)
        OUT.mkdir(parents=True)
        shutil.copytree(SITE / 'assets', OUT / 'assets')
        ordered_paths = [p for sec in sections for p in sec['pages']]
        available = {str(p) for p in ordered_paths}
        docs = []
        for sec in sections:
            for path in sec['pages']:
                md = (source_root / str(path)).read_text(encoding='utf-8')
                title = page_heading(md, display_name(path))
                description = summary_from_markdown(md, title)
                content, toc = markup(strip_primary_heading(md), path, available)
                docs.append({'title': title, 'nav_title': display_name(path), 'section': sec['name'],
                             'url': html_path(path), 'path': str(path), 'description': description,
                             'body': content, 'toc': toc,
                             'text': re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', content))[:26000]})
        for idx, doc in enumerate(docs):
            dest = OUT / doc['url']
            dest.parent.mkdir(parents=True, exist_ok=True)
            body = f'<article class="article"><h1>{esc(doc["title"])}</h1><div class="md-body">{doc["body"]}</div></article>'
            dest.write_text(page_template(title=doc['title'], description=doc['description'], body=body,
                             sections=sections, current=doc['path'], toc=doc['toc'], section=doc['section'],
                             prev=docs[idx-1] if idx else None, following=docs[idx+1] if idx+1 < len(docs) else None), encoding='utf-8')
        groups = []
        for sec in sections:
            links = ''.join(f'<li><a href="{esc(html_path(p))}">{esc(display_name(p))}</a></li>' for p in sec['pages'])
            groups.append(f'<section class="topic" id="topic-{slug(sec["folder"])}">'
                          f'<h2>{esc(sec["name"])}</h2><ul>{links}</ul></section>')
        homepage = f'<div class="home"><h1>Cybersecurity Survival Notes</h1><div class="topic-grid">{"".join(groups)}</div></div>'
        (OUT / 'index.html').write_text(page_template(title=SITE_NAME,
            description='Cybersecurity notes on Linux, networking, fundamental concepts and security tools.',
            body=homepage, sections=sections, home=True), encoding='utf-8')
        index = [{'title': d['title'], 'section': d['section'], 'url': d['url'],
                  'description': d['description'], 'text': html.unescape(d['text'])} for d in docs]
        (OUT / 'search-index.json').write_text(json.dumps(index, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
        urls = [SITE_URL] + [SITE_URL + d['url'] for d in docs]
        (OUT / 'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
            + ''.join(f'<url><loc>{esc(url)}</loc></url>\n' for url in urls) + '</urlset>\n', encoding='utf-8')
        (OUT / 'robots.txt').write_text('User-agent: *\nAllow: /\nSitemap: ' + SITE_URL + 'sitemap.xml\n', encoding='utf-8')
        (OUT / '.nojekyll').write_text('', encoding='utf-8')
        print(f'Success: {len(docs)} pages across {len(sections)} topics → {OUT}')
    finally:
        if temp:
            temp.cleanup()


if __name__ == '__main__':
    build()
