#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 non trovato. Installa python3 e riprova."
  exit 1
fi
if [ ! -d ".venv" ]; then
  echo "[1/4] Creo ambiente Python locale..."
  python3 -m venv .venv
fi
source .venv/bin/activate
echo "[2/4] Preparo il generatore..."
python3 -m pip install -q -r website/requirements.txt
echo "[3/4] Creo il sito usando i tuoi veri documenti su GitHub..."
python3 website/build.py
echo "[4/4] Apri http://127.0.0.1:8000/"
echo "Per fermare il server: Ctrl+C"
python3 -m http.server 8000 --directory _site
