(() => {
  const $ = (s) => document.querySelector(s);
  const root = document.body.dataset.root || '';
  const sidebar = $('#sidebar');
  $('#menu-toggle')?.addEventListener('click', (e) => {
    const open = sidebar.classList.toggle('open');
    e.currentTarget.setAttribute('aria-expanded', String(open));
  });
  document.addEventListener('click', (e) => {
    if (window.innerWidth <= 720 && sidebar?.classList.contains('open') && !e.target.closest('.sidebar, #menu-toggle')) sidebar.classList.remove('open');
  });
  const modal = $('#search-modal');
  const input = $('#search-input');
  const results = $('#search-results');
  let index = [];
  let loaded = false;
  const escape = (value) => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function showResults(query) {
    const q = query.trim().toLowerCase();
    if (!q) { results.innerHTML = '<div class="empty-result">Type a term, command, or topic to search.</div>'; return; }
    const terms = q.split(/\s+/).filter(Boolean);
    const ranked = index.map(doc => {
      const title = doc.title.toLowerCase();
      const section = doc.section.toLowerCase();
      const text = doc.text.toLowerCase();
      const match = terms.every(term => title.includes(term) || section.includes(term) || text.includes(term));
      const score = terms.reduce((sum,t) => sum + (title.includes(t) ? 20 : 0) + (section.includes(t) ? 5 : 0) + (text.includes(t) ? 1 : 0),0);
      return {doc,match,score};
    }).filter(x => x.match).sort((a,b) => b.score-a.score).slice(0,14);
    results.innerHTML = ranked.length ? ranked.map(({doc}) => `<a class="search-result" href="${root}${encodeURI(doc.url)}"><strong>${escape(doc.title)}</strong><small>${escape(doc.section)}</small></a>`).join('') : '<div class="empty-result">No results found.</div>';
  }
  async function openSearch() {
    modal.hidden = false;
    input.focus();
    if (!loaded) {
      try { const response = await fetch(`${root}search-index.json`); index = await response.json(); loaded = true; }
      catch { results.innerHTML = '<div class="empty-result">Search needs a web server. Run the local preview command in README.</div>'; return; }
    }
    showResults(input.value);
  }
  function closeSearch() { modal.hidden = true; }
  $('#search-toggle')?.addEventListener('click', openSearch);
  $('#search-close')?.addEventListener('click', closeSearch);
  modal.addEventListener('click', (e) => { if (e.target === modal) closeSearch(); });
  input.addEventListener('input', (e) => showResults(e.target.value));
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !modal.hidden) closeSearch();
    if (e.key === '/' && modal.hidden && !['INPUT','TEXTAREA'].includes(document.activeElement?.tagName)) { e.preventDefault(); openSearch(); }
  });
})();
