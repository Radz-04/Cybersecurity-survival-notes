#!/usr/bin/env python3
"""Build a static GitHub Pages site from existing repo Markdown. No content copied to source."""
from __future__ import annotations
import html
import json
import re
import shutil
import sys
import io
import tempfile
import urllib.request
import zipfile
from pathlib import Path
from urllib.parse import quote, urlsplit, urlunsplit

import mistune

ROOT = Path(__file__).resolve().parent.parent
SITE = ROOT / 'website'
OUT = ROOT / '_site'
REPO_URL = 'https://github.com/Radz-04/Cybersecurity-survival-notes'
SITE_URL = 'https://radz-04.github.io/Cybersecurity-survival-notes/'
SECTIONS = [
    ('Linux', 'Linux'),
    ('Networking', 'Networking'),
    ('Cybersecurity Fundamentals', 'Cybersecurity-fundamentals'),
    ('Tools', 'Tools'),
]
# Existing documents follow a logical reading order. Future documents appear automatically.
PAGE_ORDER = {
    'Linux': ['Architecture', 'Permissions', 'Cheatsheet', 'Networking'],
    'Networking': ['Basics', 'Components', 'Communication', 'Transmission', 'Protocols', 'DHCP'],
    'Cybersecurity-fundamentals': ['CIA_triad'],
    'Tools': ['Nmap'],
}
markdown = mistune.create_markdown(plugins=['table', 'strikethrough', 'url'])

def obtain_source():
    """Use the local checkout when available, otherwise fetch the public GitHub repo."""
    if (ROOT / "Networking").is_dir() and (ROOT / "Linux").is_dir():
        return ROOT, None, "local files"
    tmp = tempfile.TemporaryDirectory(prefix="cyber-notes-")
    url = "https://github.com/Radz-04/Cybersecurity-survival-notes/archive/refs/heads/main.zip"
    print("Markdown folders not found locally. Downloading the public GitHub repository...")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "cybersecurity-survival-notes-site-builder"})
        with urllib.request.urlopen(req, timeout=45) as response:
            archive = response.read()
        with zipfile.ZipFile(io.BytesIO(archive)) as src:
            # Archive is from a fixed public repository, but still reject path traversal.
            for item in src.infolist():
                output_path = (Path(tmp.name) / item.filename).resolve()
                if not output_path.is_relative_to(Path(tmp.name).resolve()):
                    raise ValueError("Invalid path inside downloaded archive")
            src.extractall(tmp.name)
        dirs = [q for q in Path(tmp.name).iterdir() if q.is_dir()]
        if len(dirs) != 1 or not (dirs[0] / "Networking").is_dir():
            raise ValueError("The downloaded repository does not contain the expected folders")
        return dirs[0], tmp, "GitHub main branch"
    except Exception as e:
        tmp.cleanup()
        raise SystemExit(
            f"ERROR: Cannot retrieve the Markdown documentation from GitHub: {e}\n"
            "Check your internet connection, or run the build from a clone of "
            "Radz-04/Cybersecurity-survival-notes containing Linux/ and Networking/.\n"
        )


def plain_title(path):
    title = path.stem.replace('_', ' ').replace('-', ' ')
    return title.replace('CIA triad', 'CIA Triad')


def slug(value):
    return re.sub(r'[^a-z0-9]+', '-', value.lower()).strip('-')


def href_from_path(path):
    return path.with_suffix('.html').as_posix()


def convert(md_text):
    content = markdown(md_text)
    # Repair markdown links to local md documents, preserving relative paths.
    def fix(match):
        url = html.unescape(match.group(1))
        if url.startswith(('http:', 'https:', 'mailto:', '#', '//')):
            return match.group(0)
        parsed = urlsplit(url)
        if not parsed.path.lower().endswith('.md'):
            return match.group(0)
        if Path(parsed.path).name.lower() == 'readme.md':
            dest = '../index.html'
        else:
            dest = str(Path(parsed.path).with_suffix('.html'))
        return f'href="{html.escape(urlunsplit(("", "", dest, parsed.query, parsed.fragment)), quote=True)}"'
    content = re.sub(r'href="([^"]+)"', fix, content)
    # Escape title attributes and assign stable, unique ids to H1-H3 for toc.
    used = {}
    toc = []
    def head(match):
        level = int(match.group(1))
        raw = match.group(2)
        title = html.unescape(re.sub(r'<[^>]+>', '', raw)).strip()
        base = slug(title) or 'section'
        used[base] = used.get(base, 0) + 1
        ident = base if used[base] == 1 else f'{base}-{used[base]}'
        if level >= 2:
            toc.append({'title':title, 'id':ident, 'level':level})
        return f'<h{level} id="{ident}">{raw}</h{level}>'
    content = re.sub(r'<h([1-3])>(.*?)</h\1>', head, content, flags=re.DOTALL)
    return content, toc


def template(title, section, body, nav, toc, current, description):
    navigation = []
    for name, directory, pages in nav:
        links = '\n'.join(
            f'<a class="nav-link {"active" if current == path.as_posix() else ""}" href="{("../" if section else "") + href_from_path(path)}">{html.escape(plain_title(path))}</a>'
            for path in pages
        )
        # Keep all groups open by default: users immediately see every document.
        navigation.append(f'<details class="nav-group" open><summary>{html.escape(name)}<span class="group-count">{len(pages)}</span></summary><div class="nav-links">{links}</div></details>')
    toc_items = ''.join(f'<a class="toc-level-{x["level"]}" href="#{x["id"]}">{html.escape(x["title"])}</a>' for x in toc)
    root = '../' if section else ''
    github = REPO_URL + ('/blob/main/' + quote(current) if current else '')
    canonical = SITE_URL + (href_from_path(Path(current)) if current else '')
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title)} | Cybersecurity Survival Notes</title>
<meta name="description" content="{html.escape(description, quote=True)}">
<meta name="theme-color" content="#fcfcfd">
<link rel="canonical" href="{html.escape(canonical, quote=True)}">
<meta property="og:title" content="{html.escape(title,quote=True)} | Cybersecurity Survival Notes">
<meta property="og:description" content="{html.escape(description,quote=True)}">
<meta property="og:type" content="article">
<meta property="og:url" content="{html.escape(canonical, quote=True)}">
<link rel="stylesheet" href="{root}assets/style.css">
<script src="{root}assets/app.js" defer></script>
</head>
<body data-root="{root}">
<header class="topbar">
  <div class="top-inner">
    <a class="brand" href="{root}index.html">
      <span class="brand-mark">~/</span>
      <span class="brand-name">Cybersecurity <strong>Survival Notes</strong></span>
    </a>
    <div class="top-actions">
      <button class="search-toggle" id="search-toggle" type="button" aria-label="Search documentation"><span class="search-icon" aria-hidden="true">⌕</span> Search <kbd>/</kbd></button>
      <a href="{REPO_URL}" class="github-top" target="_blank" rel="noopener">GitHub <span aria-hidden="true">↗</span></a>
      <a href="{REPO_URL}" class="star-top" target="_blank" rel="noopener">☆ Star repository</a>
      <button id="menu-toggle" class="menu-toggle" type="button" aria-expanded="false" aria-controls="sidebar">☰ <span class="sr-only">Menu</span></button>
    </div>
  </div>
</header>
<div class="layout">
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-content">
      <div class="sidebar-heading">DOCUMENTATION</div>
      <a class="nav-home {"active" if not current else ""}" href="{root}index.html">Overview</a>
      {''.join(navigation)}
      <div class="sidebar-footer"><a href="{REPO_URL}" target="_blank" rel="noopener">Source on GitHub ↗</a></div>
    </div>
  </aside>
  <main class="main">
    <div class="article">
      <div class="eyebrow">{html.escape(section or 'Documentation')}</div>
      {body}
      <div class="article-footer"><a href="{github}" target="_blank" rel="noopener">View source on GitHub ↗</a></div>
    </div>
  </main>
  <aside class="rightbar">{('<div class="toc-title">ON THIS PAGE</div>'+toc_items) if toc_items else '<div class="toc-title">QUICK LINKS</div><a href="'+REPO_URL+'" target="_blank" rel="noopener">GitHub repository ↗</a>'}</aside>
</div>
<div class="search-modal" id="search-modal" hidden>
  <div class="search-panel" role="dialog" aria-modal="true" aria-label="Search documentation">
    <div class="search-line"><span class="search-symbol">⌕</span><input id="search-input" type="search" autocomplete="off" placeholder="Search commands or topics…" aria-label="Search documentation"><button id="search-close" type="button" aria-label="Close search">Esc</button></div>
    <div id="search-results" class="search-results"></div>
  </div>
</div>
</body></html>"""

def build():
    source_root, temp_source, source_label = obtain_source()
    nav = []
    for name, folder in SECTIONS:
        path = source_root / folder
        if not path.is_dir(): continue
        def page_key(p):
            priorities = PAGE_ORDER.get(folder, [])
            return (0, priorities.index(p.stem)) if p.stem in priorities else (1, p.name.casefold())
        pages = sorted([p.relative_to(source_root) for p in path.glob('*.md')], key=page_key)
        if pages: nav.append((name,folder,pages))
    if not nav:
        raise SystemExit(
            "\nERROR: No Markdown documentation folders found.\n"
            "Make sure your GitHub repository contains Markdown files in its "
            "Linux/, Networking/, Tools/ and Cybersecurity-fundamentals/ directories.\n"
        )
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir()
    (OUT / 'assets').mkdir()
    for filename in ('style.css', 'app.js'):
        shutil.copy2(SITE / 'assets' / filename, OUT / 'assets' / filename)
    entries = []
    for name, folder, pages in nav:
        (OUT / folder).mkdir(exist_ok=True)
        for p in pages:
            md = (source_root / p).read_text(encoding='utf-8')
            rendered, toc = convert(md)
            title = plain_title(p)
            found = re.search(r'^#\s+(.+)$', md, flags=re.M)
            if found: title = found.group(1).strip()
            elif (found := re.search(r'^##\s+(.+)$', md, flags=re.M)): title=found.group(1).strip()
            if not re.match(r'^<h1\b', rendered.strip()):
                rendered = f'<h1>{html.escape(title)}</h1>\n' + rendered
            # Use the document's own introductory prose for search snippets.
            prose = [line.strip() for line in md.splitlines() if len(line.strip()) > 48 and not line.lstrip().startswith(('#','|','-','>','`','*','!','[','<'))]
            desc = re.sub(r'[*_`\[\]]', '', prose[0])[:157].rstrip() if prose else f'{title} — Cybersecurity Survival Notes.'
            out = OUT / href_from_path(p)
            out.write_text(template(title,name,rendered,nav,toc,p.as_posix(),desc),encoding='utf-8')
            searchable = re.sub(r'\s+',' ',re.sub(r'<[^>]+>',' ',rendered))[:12000]
            entries.append({'title':title,'section':name,'url':href_from_path(p),'text':html.unescape(searchable)})
    cards = ''.join(
        f'<a class="doc-card" href="{href_from_path(p)}"><span class="doc-card-name">{html.escape(plain_title(p))}</span><span class="doc-card-arrow">↗</span></a>'
        for _, _, pages in nav for p in pages
    )
    groups = ''.join(
        f'<section class="home-group"><div class="home-group-top"><h2>{html.escape(name)}</h2><span class="group-meta">{len(pages)} {"document" if len(pages)==1 else "documents"}</span></div>'
        f'<div class="doc-grid">{"".join(f'<a class="doc-card" href="{href_from_path(p)}"><span class="doc-card-name">{html.escape(plain_title(p))}</span><span class="doc-card-arrow">↗</span></a>' for p in pages)}</div></section>'
        for name, folder, pages in nav
    )
    home = (
        '<div class="home-intro"><div class="home-kicker"><span class="status-dot"></span> OPEN DOCUMENTATION</div>'
        '<h1 class="home-title">Cybersecurity Survival Notes<span class="period">.</span></h1>'
        '<p class="lead">Technical notes and command references, organized by topic. '
        'Read online or browse the original Markdown files on GitHub.</p>'
        f'<div class="home-cta"><a class="primary-link" href="{href_from_path(nav[0][2][0])}">Start reading <span>→</span></a>'
        f'<a class="secondary-link" href="{REPO_URL}" target="_blank" rel="noopener">View on GitHub ↗</a></div></div>'
        f'<div class="home-sections"><div class="section-label">EXPLORE DOCUMENTATION <span>{len(entries)} PAGES</span></div>{groups}</div>'
        '<div class="home-note"><strong>Maintained on GitHub.</strong> The website is built from the same Markdown files in the repository. '
        'Updates to the documentation appear here after publishing.</div>'
    )
    (OUT/'index.html').write_text(template('Overview','',home,nav,[], '', 'Cybersecurity study notes and practical technical references on Linux, networking and security tools.'),encoding='utf-8')
    (OUT/'search-index.json').write_text(json.dumps(entries,ensure_ascii=False),encoding='utf-8')
    urls=[SITE_URL]+[SITE_URL+x['url'] for x in entries]
    (OUT/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+''.join(f'<url><loc>{html.escape(u)}</loc></url>\n' for u in urls)+'</urlset>\n',encoding='utf-8')
    (OUT/'robots.txt').write_text('User-agent: *\nAllow: /\nSitemap: '+SITE_URL+'sitemap.xml\n',encoding='utf-8')
    (OUT/'.nojekyll').write_text('',encoding='utf-8')
    print(f'Built {len(entries)} documentation pages from {source_label} into {OUT}')
    if temp_source:
        temp_source.cleanup()

if __name__ == '__main__':
    build()
