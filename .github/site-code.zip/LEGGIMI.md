# Cybersecurity Survival Notes — sito HTML (versione corretta)

Il vecchio sito mostrava soltanto "Overview" perché era stato generato da una cartella che non conteneva i documenti della repository. Il vecchio generatore non segnalava l'errore.

## ANTEPRIMA LOCALE — prima di pubblicare

1. Estrai questo ZIP in **una cartella qualsiasi**, ad esempio `~/Desktop/site-notes`.
2. Apri il terminale dentro la cartella estratta.
3. Esegui:

```bash
bash preview.sh
```

4. Apri nel browser **http://127.0.0.1:8000/**.

Lo script legge automaticamente i file reali **pubblici** da `Radz-04/Cybersecurity-survival-notes` su GitHub, se nella cartella non ci sono `Linux/` e `Networking/`. Ti serve una connessione Internet alla prima generazione. Se il progetto è già clonato, puoi invece copiare la cartella `website` nel clone: in quel caso legge i Markdown locali.

Questo crea la cartella `_site/`, con una homepage che mostra i documenti, menu espandibile e 12 pagine (numero attuale). Nessun post su GitHub. Il sito non è online.

Se porta 8000 è occupata da un precedente server locale, chiudi prima quel terminale con `Ctrl+C` oppure modifica il numero della porta nell'ultima riga di `preview.sh`.

## PUBBLICAZIONE CON GITHUB PAGES

Solo dopo che l'anteprima ti piace:

1. Copia **soltanto** la cartella `website/` e il file `.github/workflows/pages.yml` nella radice del tuo clone della repository originale (a fianco di `Linux/`, `Networking/`, `Tools/`, `README.md`). Non copiare `_site/` o `.venv/`.
2. Vai sulla repo GitHub: `Settings → Pages → Build and deployment → Source: GitHub Actions`.
3. Dal clone della repo:

```bash
git add website .github/workflows/pages.yml
git commit -m "Add documentation website"
git push origin main
```

4. Controlla `Actions` fino al completamento della pubblicazione.

Indirizzo previsto: https://radz-04.github.io/Cybersecurity-survival-notes/

## AGGIORNAMENTI

- Modifichi o aggiungi `Networking/DNS.md` → fai commit/push nella repo → GitHub Actions genera automaticamente la pagina e aggiorna i menu.
- Le quattro cartelle sincronizzate sono `Linux`, `Networking`, `Cybersecurity-fundamentals` e `Tools`.
- Nuove cartelle principali richiedono di aggiungere una voce a `SECTIONS` in `website/build.py`.
- Il tuo `README.md` originale e gli appunti non vengono toccati.
- La cartella `_site/` è generata: non inserirla nel commit.

## NOTA SULLA RICERCA E GOOGLE

La ricerca funziona su titoli e contenuti dopo l'avvio del server HTTP. Il generatore crea anche `sitemap.xml`, `robots.txt` e metadati per i motori di ricerca. Nessuno di questi garantisce l'indicizzazione o più stelle GitHub.
